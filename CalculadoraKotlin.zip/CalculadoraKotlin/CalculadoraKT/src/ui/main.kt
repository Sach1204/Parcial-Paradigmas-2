package ui

import modelo.CalculadoraConMemoria

fun main() {
    val calculadora = CalculadoraConMemoria()
    val interfaz = InterfazUsuario(calculadora)
    interfaz.iniciar()
}

