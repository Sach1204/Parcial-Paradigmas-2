package ui

import modelo.CalculadoraConMemoria

class InterfazUsuario(private val calculadora: CalculadoraConMemoria) {
    fun iniciar() {
        var continuar = true

        while (continuar) {
            mostrarMenu()
            val opcion = leerOpcion()
            continuar = procesarOpcion(opcion)
        }
        println("Calculadora terminada.")
    }

    private fun mostrarMenu() {
        println("\nSeleccione una operación:")
        println("1. Suma")
        println("2. Resta")
        println("3. Multiplicación")
        println("4. División")
        println("5. Seno")
        println("6. Coseno")
        println("7. Tangente")
        println("8. Potencia")
        println("9. Raíz")
        println("10. Logaritmo base 10")
        println("11. Logaritmo natural")
        println("12. Exponencial")
        println("13. Grados a Radianes")
        println("14. Radianes a Grados")
        println("15. Guardar en Memoria")
        println("16. Recuperar de Memoria")
        println("17. Limpiar Memoria")
        println("18. Evaluar expresión")
        println("19. Salir")
    }

    private fun leerOpcion(): Int {
        print("Opción: ")
        return readLine()?.toIntOrNull() ?: 0
    }

    private fun procesarOpcion(opcion: Int): Boolean {
        when (opcion) {
            in 1..4 -> manejarOperacionesBasicas(opcion)
            in 5..7 -> manejarOperacionesTrigonometricas(opcion)
            8 -> manejarPotencia()
            9 -> manejarRaiz()
            10 -> manejarLogaritmoBase10()
            11 -> manejarLogaritmoNatural()
            12 -> manejarExponencial()
            13 -> manejarGradosARadianes()
            14 -> manejarRadianesAGrados()
            15 -> manejarGuardarEnMemoria()
            16 -> manejarRecuperarMemoria()
            17 -> calculadora.limpiarMemoria()
            18 -> manejarEvaluarExpresion()
            19 -> return false
            else -> println("Opción no válida.")
        }
        return true
    }

    private fun leerNumeroOANS(mensaje: String): Double? {
        print("$mensaje (o deje en blanco para usar ANS): ")
        return readLine()?.toDoubleOrNull() ?: calculadora.obtenerANS()
    }

    private fun manejarOperacionesBasicas(opcion: Int) {
        val num1 = leerNumeroOANS("Ingrese el primer número") ?: return
        val num2 = leerNumeroOANS("Ingrese el segundo número") ?: return

        val resultado = when (opcion) {
            1 -> calculadora.sumar(num1, num2)
            2 -> calculadora.restar(num1, num2)
            3 -> calculadora.multiplicar(num1, num2)
            4 -> calculadora.dividir(num1, num2)
            else -> Double.NaN
        }
        calculadora.guardarEnMemoria(resultado)
        println("Resultado: $resultado")
    }

    private fun manejarOperacionesTrigonometricas(opcion: Int) {
        val angulo = leerNumeroOANS("Ingrese el ángulo") ?: return
        print("¿El ángulo está en radianes? (s/n): ")
        val enRadianes = readLine()?.toLowerCase() == "s"

        val resultado = when (opcion) {
            5 -> calculadora.seno(angulo, enRadianes)
            6 -> calculadora.coseno(angulo, enRadianes)
            7 -> calculadora.tangente(angulo, enRadianes)
            else -> Double.NaN
        }
        calculadora.guardarEnMemoria(resultado)
        println("Resultado: $resultado")
    }

    private fun manejarPotencia() {
        val base = leerNumeroOANS("Ingrese la base") ?: return
        val exponente = leerNumeroOANS("Ingrese el exponente") ?: return
        val resultado = calculadora.potencia(base, exponente)
        calculadora.guardarEnMemoria(resultado)
        println("Resultado: $resultado")
    }

    private fun manejarRaiz() {
        val numero = leerNumeroOANS("Ingrese el número") ?: return
        val indice = leerNumeroOANS("Ingrese el índice de la raíz") ?: return
        val resultado = calculadora.raiz(numero, indice)
        calculadora.guardarEnMemoria(resultado)
        println("Resultado: $resultado")
    }

    private fun manejarLogaritmoBase10() {
        val numero = leerNumeroOANS("Ingrese el número") ?: return
        val resultado = calculadora.logaritmoBase10(numero)
        calculadora.guardarEnMemoria(resultado)
        println("Resultado: $resultado")
    }

    private fun manejarLogaritmoNatural() {
        val numero = leerNumeroOANS("Ingrese el número") ?: return
        val resultado = calculadora.logaritmoNatural(numero)
        calculadora.guardarEnMemoria(resultado)
        println("Resultado: $resultado")
    }

    private fun manejarExponencial() {
        val numero = leerNumeroOANS("Ingrese el número") ?: return
        val resultado = calculadora.exponencial(numero)
        calculadora.guardarEnMemoria(resultado)
        println("Resultado: $resultado")
    }

    private fun manejarGradosARadianes() {
        val grados = leerNumeroOANS("Ingrese los grados") ?: return
        val resultado = calculadora.gradosARadianes(grados)
        calculadora.guardarEnMemoria(resultado)
        println("Resultado en radianes: $resultado")
    }

    private fun manejarRadianesAGrados() {
        val radianes = leerNumeroOANS("Ingrese los radianes") ?: return
        val resultado = calculadora.radianesAGrados(radianes)
        calculadora.guardarEnMemoria(resultado)
        println("Resultado en grados: $resultado")
    }

    private fun manejarGuardarEnMemoria() {
        print("Ingrese el valor a guardar en memoria: ")
        val valor = readLine()?.toDoubleOrNull() ?: return
        calculadora.guardarEnMemoria(valor)
    }

    private fun manejarRecuperarMemoria() {
        val memoria = calculadora.recuperarMemoria()
        if (memoria != null) {
            println("Valor en memoria: $memoria")
        } else {
            println("No hay valor en memoria.")
        }
    }

    private fun manejarEvaluarExpresion() {
        println("Funciones disponibles: sin(), cos(), tan(), log(), ln(), exp(), sqrt()")
        println("Constantes disponibles: pi, e")
        print("Ingrese la expresión a evaluar: ")
        val expresion = readLine()
        if (expresion != null) {
            try {
                val resultado = calculadora.evaluarExpresion(expresion)
                println("Resultado: $resultado")
            } catch (e: Exception) {
                println("Error al evaluar la expresión: ${e.message}")
            }
        }
    }
}
