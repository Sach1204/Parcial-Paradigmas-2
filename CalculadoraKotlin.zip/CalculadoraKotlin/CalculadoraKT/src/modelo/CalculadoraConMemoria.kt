package modelo

import util.Evaluador

class CalculadoraConMemoria : CalculadoraCientifica() {
    private var memoria: Double? = null
    private val evaluador = Evaluador(this)

    fun guardarEnMemoria(valor: Double) {
        memoria = valor
        println("Valor guardado en memoria: $valor")
    }

    fun recuperarMemoria(): Double? {
        return memoria?.also { println("Valor recuperado de memoria: $it") }
    }

    fun limpiarMemoria() {
        memoria = null
        println("Memoria borrada.")
    }

    fun obtenerANS(): Double? = memoria

    fun evaluarExpresion(expresion: String): Double {
        val resultado = evaluador.evaluar(expresion)
        guardarEnMemoria(resultado)
        return resultado
    }
}