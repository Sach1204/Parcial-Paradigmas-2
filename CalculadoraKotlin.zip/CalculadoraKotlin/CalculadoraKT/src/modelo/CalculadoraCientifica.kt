package modelo
import kotlin.math.*
open class CalculadoraCientifica : Calculadora() {
    fun seno(angulo: Double, enRadianes: Boolean = true): Double =
        if (enRadianes) sin(angulo) else sin(Math.toRadians(angulo))

    fun coseno(angulo: Double, enRadianes: Boolean = true): Double =
        if (enRadianes) cos(angulo) else cos(Math.toRadians(angulo))

    fun tangente(angulo: Double, enRadianes: Boolean = true): Double =
        if (enRadianes) tan(angulo) else tan(Math.toRadians(angulo))

    fun potencia(base: Double, exponente: Double): Double = base.pow(exponente)

    fun raiz(numero: Double, indice: Double): Double {
        return if (indice == 0.0) {
            println("Error: El índice no puede ser cero.")
            Double.NaN
        } else numero.pow(1 / indice)
    }

    fun logaritmoBase10(numero: Double): Double = if (numero > 0) log10(numero) else Double.NaN
    fun logaritmoNatural(numero: Double): Double = if (numero > 0) ln(numero) else Double.NaN
    fun exponencial(numero: Double): Double = exp(numero)

    fun gradosARadianes(grados: Double): Double = Math.toRadians(grados)
    fun radianesAGrados(radianes: Double): Double = Math.toDegrees(radianes)
}