package modelo
import kotlin.math.*

open class Calculadora {
    open fun sumar(a: Double, b: Double): Double = a + b
    open fun restar(a: Double, b: Double): Double = a - b
    open fun multiplicar(a: Double, b: Double): Double = a * b
    open fun dividir(a: Double, b: Double): Double {
        return try {
            if (b == 0.0) throw ArithmeticException("División por cero")
            a / b
        } catch (e: ArithmeticException) {
            println(e.message)
            Double.NaN
        }
    }
}
