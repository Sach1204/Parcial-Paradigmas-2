package util

import modelo.CalculadoraCientifica

class Evaluador(private val calculadora: CalculadoraCientifica) {
    private var posicion = 0
    private var expresion = ""

    fun evaluar(expr: String): Double {
        expresion = expr.replace(" ", "")
        posicion = 0
        return expresionAritmetica()
    }

    private fun expresionAritmetica(): Double {
        var resultado = termino()

        while (posicion < expresion.length) {
            when (expresion[posicion]) {
                '+' -> {
                    posicion++
                    resultado = calculadora.sumar(resultado, termino())
                }
                '-' -> {
                    posicion++
                    resultado = calculadora.restar(resultado, termino())
                }
                ')' -> return resultado
                else -> if (posicion < expresion.length && !expresion[posicion].isDigit() &&
                    expresion[posicion] != '*' && expresion[posicion] != '/') {
                    posicion++
                } else {
                    break
                }
            }
        }
        return resultado
    }

    private fun termino(): Double {
        var resultado = factor()

        while (posicion < expresion.length) {
            when (expresion[posicion]) {
                '*' -> {
                    posicion++
                    resultado = calculadora.multiplicar(resultado, factor())
                }
                '/' -> {
                    posicion++
                    resultado = calculadora.dividir(resultado, factor())
                }
                else -> break
            }
        }
        return resultado
    }

    private fun factor(): Double {
        if (posicion >= expresion.length) return 0.0

        if (expresion[posicion] == '(') {
            posicion++
            val resultado = expresionAritmetica()
            if (posicion < expresion.length && expresion[posicion] == ')') {
                posicion++
            }
            return resultado
        }

        // Manejar funciones trigonométricas y otras funciones matemáticas
        if (posicion + 3 < expresion.length) {
            when {
                expresion.substring(posicion).startsWith("sin(") -> return manejarFuncion(4) { calculadora.seno(it, true) }
                expresion.substring(posicion).startsWith("cos(") -> return manejarFuncion(4) { calculadora.coseno(it, true) }
                expresion.substring(posicion).startsWith("tan(") -> return manejarFuncion(4) { calculadora.tangente(it, true) }
                expresion.substring(posicion).startsWith("log(") -> return manejarFuncion(4) { calculadora.logaritmoBase10(it) }
                expresion.substring(posicion).startsWith("ln(") -> return manejarFuncion(3) { calculadora.logaritmoNatural(it) }
                expresion.substring(posicion).startsWith("exp(") -> return manejarFuncion(4) { calculadora.exponencial(it) }
                expresion.substring(posicion).startsWith("sqrt(") -> return manejarFuncion(5) { calculadora.raiz(it, 2.0) }
            }
        }
        return leerNumero()
    }

    private fun manejarFuncion(prefixLength: Int, operation: (Double) -> Double): Double {
        posicion += prefixLength
        val argumento = expresionAritmetica()
        if (posicion < expresion.length && expresion[posicion] == ')') {
            posicion++
        }
        return operation(argumento)
    }

    private fun leerNumero(): Double {
        val inicio = posicion
        while (posicion < expresion.length &&
            (expresion[posicion].isDigit() || expresion[posicion] == '.' ||
                    (posicion == inicio && expresion[posicion] == '-'))) {
            posicion++
        }
        return expresion.substring(inicio, posicion).toDoubleOrNull() ?: 0.0
    }
}
